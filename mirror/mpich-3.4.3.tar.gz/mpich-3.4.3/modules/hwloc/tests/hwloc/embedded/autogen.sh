:
autoreconf -ivf
